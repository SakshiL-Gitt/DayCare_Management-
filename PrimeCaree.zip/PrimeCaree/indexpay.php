<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="payment_process.php",method="post">
       Name :  <input type="textbox" name="dname" id="dname"><br><br>
       amount :  <input type="textbox" name="damt" id="damt"><br><br>
      <input type="button" value="pay" name="dbtn" id="dbtn" onclick="razor()"><br><br>
</form>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="script.js"></script>

<script>
    function razor(){
      var dname=jQuery('#dname').val();
      var damt=jQuery('#damt').val();
    //   var week=jQuery('#dur').val();
    //   var mobile=jQuery('#mobile').val();
    //  var name=document.getElementById('name').values();
    //  var amt=document.getElementById('amt').values();


    jQuery.ajax({ 
              url:'payment_process.php',
              type:'post',
              data:"dname="+dname+"&damt"+damt,
              success:function(result){
                var options = {
                  "key": "rzp_test_WTYBWMgBUTcYie", // Enter the Key ID generated from the Dashboard
                  "amount": damt *100, 
                 "currency": "INR",
                 "name": "Prime Care",
                 "description": "Test Transaction",
                  "image": "https://example.com/your_logo",
                 "handler": function (response){
        
                     jQuery.ajax({ 
                      url:'payment_process.php',
                      type:'post',
                      data:"payment_id="+response.razorpay_payment_id,
                      success:function(result){
                     window.location.href="thank_you.php";
           }
          });


        }
     };

     var rzpd = new Razorpay(options);
             rzpd.open();


   }
});
}

          </script>
</body>
</html>