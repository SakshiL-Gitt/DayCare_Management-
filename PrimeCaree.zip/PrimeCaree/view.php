<!doctype html> 
<html lang="en">  
<head>     
    <meta charset="utf-8">     
    <meta name="viewport" content="width=device-width, initial-scale=1">     
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">      
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"   integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="        
     crossorigin="anonymous" referrerpolicy="no-referrer" />      
    <style>         
    #cimg {            
         object-fit: scale-down;             
         object-position: center center;            
          height: 200px;            
           width: 200px;        
        }         
    .card-body {            
         padding: 20px;         
        }          
    .form-group {             
         margin-bottom: 20px;        
        }          
        
    .control-label {              
        font-weight: bold;         
        }     
    </style>  
</head> 

<?php 
require_once('config.php'); 
?> 

<html>
    <body>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>     
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"         integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>     
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>     
        <script src="script.js"></script>     
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"         crossorigin="anonymous"></script>   
        <div class="content py-3">         
            <!-- <form action="view.php" method="GET"> -->           
            <div class="container-fluid">                
                <div class="card card-outline card-info shadow rounded-0">   
                    <div class="card-header">                         
                        <h4 class="card-title"> 
                            <?php= isset($id) ? "" : "User Details"  ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                            
                             <a href="users.php" class="btn btn-success mr-2"  style="height: 30px; line-height: 18px; background-color: grey; border-color: grey,color:white;";>Close Window<a>                
                    </div> 
                    <div class="card-body">                         
                        <div class="container-fluid">                             
                            <form action="view.php" method="GET">                                 
                                <?php  $id = $_POST['id']; // Assuming you're passing the ID through GET method            
                                $stmt = $con->prepare("SELECT * FROM enrollment WHERE id = :id LIMIT 1");            
                                $stmt->bindParam(':id', $id);             
                                $stmt->execute();            
                                $row = $stmt->fetch(PDO::FETCH_ASSOC);             
                                ?>
                                <input type="hidden" name="id" value="<?php= isset($id) ? $id : '' ?>">              
                                <legend class="text-navy">Information</legend>             
                                <div class="row">                 
                                    <div class="form-group col-md-4">                    
                                         <label class="control-label text-primary">Child First Name:</label>                     
                                         <?php echo $row['child_fname'] ?>                 
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Child Surname:</label>                     
                                        <?php echo $row['child_lname'] ?>                 
                                    </div>                
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Date of Birth:</label>                     
                                        <?php echo $row['dob'] ?>                 
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Allergy:</label>                     
                                        <?php echo $row['allergy'] ?>                 
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Parent Name:</label>                     
                                        <?php echo $row['parent_fname'] ?>                 
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Parent Surname:</label>                     
                                        <?php echo $row['parent_lname'] ?>                 
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Email:</label>                     
                                        <?php echo $row['email'] ?>                
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Contact:</label>                     
                                        <?php echo $row['contact'] ?>                 
                                    </div>                  
                                    <div class="form-group col-md-4">                     
                                        <label class="control-label text-primary">Address:</label>                      
                                        <?php echo $row['address'] ?>                 
                                    </div>                 
                                    <div class="form-group col-md-4">                     
                                        <input type="button" value="Pay" onclick="razor()">                 
                                    </div>              
                                </div>         
                            </form>     
                        </div> 
                    </div>    
                </div>             
            </div>  
        </div>
             
        <div class="card-body">                         
            <div class="container-fluid">                            
                 <form action="view.php" method="GET">                                 
                    <?php             
                    $id = $_POST['id']; // Assuming you're passing the ID through GET method            
                    $stmt = $con->prepare("SELECT * FROM enrollment WHERE id = :id LIMIT 1");             
                    $stmt->bindParam(':id', $id);             
                    $stmt->execute();             
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);             
                    ?> 
                    <div>         
                        <?php               
                          if(isset($_POST['submit']))             
                          {                        
                             $child_fname = $_POST['child_fname'];                         
                             $child_mname = $_POST['child_mname'];                         
                             $child_lname = $_POST['child_lname'];                         
                             $dob = $_POST['dob'];                         
                             $allergy = $_POST['allergy'];                         
                             $gender = $_POST['gender'];                                             
                             $parent_fname = $_POST['parent_fname'];                         
                             $parent_mname = $_POST['parent_mname'];                         
                             $parent_lname = $_POST['parent_lname'];                         
                             $contact = $_POST['contact'];                         
                             $email = $_POST['email'];                         
                             $address = $_POST['address'];                         
                             // $image = $_POST['image'];                          
                             $query = "insert into enrollment (child_fname,child_mname,child_lname,dob,allergy,gender,parent_fname,parent_mname,parent_lname,contact,email,address)                        
                             values(?,?,?,?,?,?,?,?,?,?,?,?)";                                                
                            $stmp = $con->prepare($query );                         
                            $result = $stmp->execute([$child_fname , $child_mname , $child_lname, $dob,$allergy,$gender,$parent_fname,$parent_mname,$parent_lname,$contact,$email,$address]);                                                
                            if($result)                         
                            {                             
                                echo '<script> alert("Register Successfully");</script>';            
                            }                         
                            else
                            {                             
                                echo "Register Unsuccessfull";                         
                            }                      
                        }          
                        ?>   
                    </div>
                    <script>         
                        function razor() 
                        {             
                            var dname = jQuery('#dname').val();            
                            var damt = jQuery('#damt').val();             
                            //   var week=jQuery('#dur').val();            
                            //   var mobile=jQuery('#mobile').val();             
                            //  var name=document.getElementById('name').values();             
                            //  var amt=document.getElementById('amt').values();              
                            jQuery.ajax({                 
                                url: 'payment_process.php',                 
                                type: 'post',                 
                                data: "dname=" + dname + "&damt" + damt,success: function (result) 
                                {                     
                                    var options = {                         
                                        "key": "rzp_test_WTYBWMgBUTcYie", // Enter the Key ID generated from the Dashboard                         
                                        "amount": damt * 100,                         
                                        "currency": "INR",                         
                                        "name": "Prime Care",                         
                                        "description": "Test Transaction",                         
                                        "image": "https://example.com/your_logo",                         
                                        "handler": function (response) {                              
                                            jQuery.ajax({                                 
                                            url: 'payment_process.php',                                 
                                            type: 'post',                                 
                                            data: "payment_id=" + response.razorpay_payment_id,                                 
                                            success: function (result) {                                     
                                                window.location.href = "thank_you.php";                                 
                                                }                             
                                            });                          
                                        }                     
                                    };                      
                                        var rzpd = new Razorpay(options);                     
                                        rzpd.open();                  
                                    }             
                                });         
                            }      
                            </script> 
                        </body> 
                    </html>  
    </body>
</html>