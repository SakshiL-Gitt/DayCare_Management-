<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="contact.css">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-warning  fixed-top text-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><span class="text-primary">Prime</span>Care</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav justify-content-center ">
          <li class="nav-item">
            <a class="nav-link" href="#home"><span class="text-dark">Home&nbsp;</span></a>
          </li>
          <li class="nav-item" style="color: black;">
            <a class="nav-link" href="#aboutUs"><span class="text-dark">&nbsp;AboutUs&nbsp;</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#service"><span class="text-dark">&nbsp;Service&nbsp;</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="team.html"><span class="text-dark">&nbsp;Babysitters&nbsp;</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="registration.php"><span class="text-dark">&nbsp;Enrollment&nbsp;</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contact"><span class="text-dark">&nbsp;Contact&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></a>
          </li>
        </ul>
      </div>
      <ul class="navbar-nav justify-content-right ">
      <li class="nav-item">
          <a class="nav-link" href="bslogin.php">BS Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Admin</a>
        </li>
      </ul>
  </nav>


  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
        aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
        aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
        aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="img/child2.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="img/kinder.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="img/kindergarten.jpg" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
      data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
      data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

  <section id="aboutUs" class="aboutUs section-padding">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-16 col-16">
          <div class="about-img">
            <img src="img/baby.png" alt="" class="img-fluid">
          </div>
        </div>
        <div class="col-lg-6 col-md-12 col-12 ps-lg-5 mt-md-5">
          <div class="about-text">
            <h2>About Us<br></h2>
            <p style="font-size: 18px;">PrimeCare is India’s leading chain of Preschools and Daycare centres,
              valued for supporting over 60,000 families through top-notch learning and
              care for their children. Our focus is on creating a safe, nurturing and engaging
              environment for little ones to learn and grow, supported by passionate facilitators,
              modern infrastructure, and a proven pedagogy.</p>
            <a href="#" class="btn btn-warning">Learn more</a>
          </div>

        </div>
      </div>
    </div>
  </section>


  <section id="service" class="why_section layout_padding">
    <div class="container">
      <div class="heading_container" style="text-align: center;">
        <h2>
          Why Choose Us
        </h2>
      </div>
      <div class="why_container">
        <div class="box">
          <div class="img-box">
            <img src="img/health.webp" alt="" />
          </div>
          <div class="detail-box">
            <p>
            <h4>Health & Safety</h4>
            At PrimeCentre, we take the safety of our children, teachers and staff very
            seriously and all our operations are aligned to ensure KLAY is always a
            safe and happy place for all.</p>
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="img/infra.webp" alt="" />
          </div>
          <div class="detail-box">
            <p>
            <h4>Infrastructure & Facilities</h4>
            
            We create for your children a ‘home away from home’, a place where they feel
            loved and happy. With world class infrastructure and child friendly toys and
            equipment, we are your little one’s second home!</p>
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="img/child2.jpg" alt="" />
          </div>
          <div class="detail-box">
            <p>
            <h4>Integrated Learning and Advancement Program</h4>
            We create a nurturing environment where children grow through play, 
            developing essential skills in a fun and engaging way. Our approach blends
            structured activities and free play </p>
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="img/do-it1.png" alt="" />
          </div>
          <div class="detail-box">
            <p>
              <h4>Holistic child development approach</h4>
              We create a nurturing environment where children grow through play, 
              developing essential skills in a fun and engaging way. Our approach blends
              structured activities and free play </p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <br><br><br>
  <!-- contact -->
   
    
    <section id="contact" class="address" >
    <header >
    <h1>Contact</h1>
  </header>
  <br>
  <main>
   
    <section class="address">
      <h2>Address</h2>
      <p>123 Sunshine Avenue</p>
      <p>Cityville, State 12345</p>
    </section>
    <section class="timings">
      <h2>Timings</h2>
      <p>Monday - Friday: 7:00 AM - 6:00 PM</p>
      <p>Saturday - Sunday: Closed</p>
    </section>
    <section class="working-days">
      <h2>Working Days</h2>
      <p>Monday - Friday</p>
      <img src="phone.png" alt="" style="width:20px;height: 20px;"&nbsp &nbsp>.  1234567892
    </section>
  </main>
</section>
</body>
</html>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

  <!-- <section class="team_section layout_padding">
    <div class="container-fluid">
      <div class="heading_container">
        <h2>
          Our Team
        </h2>
        <p>
          words which don't look even slightly believable. If you are going to use a passage m
        </p>
      </div>
      <div class="carousel-wrap ">
        <div class="owl-carousel team_carousel">
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="team1.jpg" alt="" width="180" height="220"/>
              </div>
              <div class="detail-box">
                
                <h6>
                  Hennry bilisom
                </h6>
               
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="team2.jpg" alt="" width="180" height="220"/>
              </div>
              <div class="detail-box">
                <h6>
                  jessi
                </h6>
                
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="team3.jpg" alt="" width="180" height="220"/>
              </div>
              <div class="detail-box">
                <h6>
                 mehata
                </h6>
                
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="team4.jpg" alt="" width="180" height="220"/>
              </div>
              <div class="detail-box">
                <h6>
                kuhu
                </h6>
                
              </div>
            </div>
          </div>
        
          
            
          
        </div>
      </div>
    </div>
  </section> -->