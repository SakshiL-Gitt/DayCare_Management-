<?php
    
    
     
     //Database

     $DB_SERVER = "localhost";
     $DB_USER = "root";
     $DB_PASS = '';
     $DB_NAME = "sejal";
      $con = new PDO('mysql:host=localhost;dbname='.$DB_NAME.';charset=utf8',$DB_USER,$DB_PASS);
      $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

//$con=new mysqli( $DB_SERVER,$DB_USER,$DB_PASS,$DB_NAME);

     // Check connection
     if (!$con)
     {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
     }
     
     
?>
