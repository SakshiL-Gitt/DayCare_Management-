<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
  </head>
  <body>
  


  <nav class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color:#00ff5573;">
		Users
  </nav>

	<div class="container">

      <?php

        if(isset($_GET['msg']))
        {
          $msg = $_GET['msg'];
          echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
          '.$msg.'
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }
       ?>
		

        <table class="table table-hover text-center">
          <thead class="table-dark">
            <tr>
             <th scope="col">ID</th>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Price</th>
              <th scope="col">Payment Status</th>
              <th scope="col">Contact</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  
                  require_once('config.php');
                  

                  $sql = "SELECT enrollment.id AS enrollment_id, enrollment.child_fname, enrollment.child_lname, payment.amount, payment.payment_status,payment.contact FROM enrollment JOIN payment ON enrollment.id = payment.id";

                $result = $con->query($sql);
                while ($row = $result->fetch(PDO::FETCH_ASSOC))
                {
                  ?>
                      <tr>
                        <th><?php echo $row['enrollment_id']?></th>
                        <td><?php echo $row['child_fname']; ?></td>
                        <td><?php echo $row['child_lname']; ?></td>
                        <td><?php echo $row['amount']; ?></td>
                        <td>
                            <?php
                            $status = $row['payment_status'];
                            $class = $status === 'success' ? 'btn-success' : 'btn-danger';
                            ?>
                            <button type="button" class="btn <?php echo $class; ?>">
                                <?php echo $status; 
                              
                            ?>
                            </button>
                        </td>
                        <td><?php echo $row['contact']; ?></td>
                        <td>
                              <a href="view.php?id=<?php echo $row['enrollment_id'];?>" class="btn btn-info btn-sm"> View </a>
                        </td>
                      </tr>


                      <?php



                    
                } 
                $conn = null;

                ?>
              
            
          </tbody>
        </table>

	</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
  </body>
</html>