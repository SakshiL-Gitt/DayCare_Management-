<?php
  include ("loginConn.php");
?>  
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="login.css">
</head>
<body>
  <div class="center">
    <h1>Login</h1>

    <form action="loglogic.php" method="POST" name="form">
      
      <div class="txt_field">
        <input type="email" name="email1" required>
        <span></span>
        <label>Email</label>
      </div>
      <div class="txt_field">
        <input type="password" name="pass1"  required>
        <span></span>
        <label>Password</label>
      </div>
      <input type="submit" value="Login" name="submit"><br><br><br>
  
    </form>
  </div>
  <button class="back-to-main" onclick="window.location.href = 'index.php';" style="
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 530px;
            margin-left:1160px;

            cursor: pointer;">Back</button>
</body>

</html>