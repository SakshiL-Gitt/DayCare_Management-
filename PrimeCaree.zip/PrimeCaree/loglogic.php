
<?php
  include ("loginConn.php");

  if(isset($_POST['submit']))
  {
    $email=$_POST['email1'];
    $pass=$_POST['pass1'];
    $sql="select * from login where email = '$email' and password = '$pass'";
    $result=mysqli_query($conn,$sql);
    // $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
     $count=mysqli_num_rows($result);
     if($count==1){
        echo " congrats";
         header("Location:Dashhh\index.php");
     }
    else
    {
        echo '<script>
         alert("Login Failed");
         </script>';
         
    }
  }
?>