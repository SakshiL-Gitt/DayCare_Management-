<?php
session_start();

include("loginConn.php");

if(isset($_POST['damt']) && isset($_POST['dname']) ){
    // $amount=$_POST['amt'];
    $date=date('Y-m-d:i:s');
    $name=$_POST['name'];
    $email=$_POST['email'];
    $dur=$_POST['dur'];
    $mobile=$_POST['mobile'];
    $amount=$_POST['amt'];
    $payment_status="Pending";

   

 $qu="INSERT INTO pay(name,amount,Status,Date) VALUES ('$name','$amt','$date','$payment_status')";
 mysqli_query($conn,$qu);

 $_SESSION['OID'] = mysqli_insert_id($conn);
}
 
 if(isset($_POST['payment_id']) && isset($_SESSION['OID'])){
    $payment_id=$_POST['payment_id'];
    mysqli_query($conn,"UPDATE pay set status='Confirmed', p_id='$payment_id' where id='".$_SESSION['OID']."'");
}
?>