
 <?php
require_once('Registerconfig.php');
?> 

<!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="Registerstyle.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>Responsive Enrollment Form </title> 
</head>
<body>

        
    <div class="container">
        <header>Enrollment    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      
            <!-- <label for="profile">Child's Profile:</label> -->
            <!-- <input type="file"  name="image" accept="image/*" > -->
             </header>

        <form action="checkout.php" method="post">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Child Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>First Name</label>
                            <input type="text" placeholder="Enter your name" name ="child_fname" required>
                        </div>

                        <div class="input-field">
                            <label>Middle Name (optional)</label>
                            <input type="text" placeholder="Enter your name" name ="child_mname" >
                        </div>

                        <div class="input-field">
                            <label>Last Name</label>
                            <input type="text" placeholder="Enter your name" name ="child_lname" required>
                        </div>

                        <div class="input-field">
                            <label>Date of Birth</label>
                            <input type="date" placeholder="Enter birth date" name = "dob" required>
                        </div>

                        <div class="input-field">
                            <label>Allergy From Anything </label>
                            <input type="text" placeholder="" name ="allergy" >
                        </div>

                        
                        <div class="input-field">
                            <label >Gender</label>
                            <select  name="gender" required>
                                <option disabled selected>Select gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="others">Others</option>
                            </select>
                        </div>


                       
                    </div>
                </div>

                <div class="details ID">
                    <span class="title">Parent / Guardian's Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>First Name </label>
                            <input type="text" placeholder="" name ="parent_fname" required>
                        </div>

                        <div class="input-field">
                            <label>Middle Name</label>
                            <input type="text" placeholder="" name ="parent_mname" required>
                        </div>

                        <div class="input-field">
                            <label>Last Name</label>
                            <input type="text" placeholder="" name ="parent_lname" required>
                        </div>

                        <div class="input-field">
                            <label>Contact</label>
                            <input type="text" placeholder="" name ="contact"required>
                        </div>

                        <div class="input-field">
                            <label>Email</label>
                            <input type="text" placeholder="" name ="email" required>
                        </div>

                        <div class="input-field">
                            <label>Address</label>
                            <textarea  name="address" required="required" cols="2" rows="2"  maxlength="200" name ="address"></textarea>
                        </div>

                       
                    </div>

                    
                    

                     <!-- <button class="nextBtn"> -->
                        <input type="submit" name="submit" value="Submit">
                        <!-- <span class="btnText" >Next</span> -->
                        <!-- <i class="uil uil-navigator"></i>
                    </button>  -->
                    
                </div> 
                <button class="back-to-main" onclick="window.location.href = 'index.php';" style="
            background-color: #eff226;
            border: none;
            color: black;
         
            text-align: center;
            text-decoration: none;
            
            font-size: 16px;
            margin-top: 10px;
            margin-left:600px;
            cursor: pointer;
">Back</button>
            </div>


                

                   
                </div> 
            </div>
        </form>
    </div>
    
    <script src="script.js"></script>
</body>
</html>