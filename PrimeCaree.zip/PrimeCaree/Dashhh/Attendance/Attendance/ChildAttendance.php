<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baby Attendance</title>
    <style>

       body{
        font-family:Arial,sans-serif;
        margin:0;
        padding :0;
        background-image:url('https://i.pinimg.com/originals/6d/60/f8/6d60f8c86bb29ae65c26370be7429f0d.jpg');
        

       }

       .container{
        max-width:800px;
        margin: 20px auto;
        padding:20px;
        background-color:#fff;
        border-radius:8px;
        box-shadow:0 0 10px rgba(0,0,0,0.1);

       }
       h1{
        text-align:center;
       }
       form{
        margin-top:50px;
       }
       label{
        display:block;
        margin-bottom:8px;
       }
       input[type="submit"]{
        background-color:#0096FF;
        color:white;
        padding:5px 20px;
        border:none;
        border-radius:4px;
        cursor:pointer;
       font-size: 16px;
       }
       input[type="submit"]:hover{
        background-color: #0096FF;
       }
       .back-to-main {
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 150px;
            margin-left:1160px;

            cursor: pointer;
       }
       

        </style>
</head>
<body>
    <div class="container">
        <h1>Babies Attendance</h1>
        <form method="post">
            Child's Name: <input type="text" id="chid_name" name="chid_name" required><br><br>
            Roll no.    :  <input type="text" id="roll_no" name ="roll_no" required><br><br>
            <label for="chid_attend" >Children Attendance:</label>
            <input type="checkbox" name="status" value="present">Present<br>
            <input type="checkbox" style= "color:#990FF" name="status" value="absent" >Absent<br><br>
            <input type="submit" value="submit_attendance" name="submit_attend">
    </form>
    </div>

 <div>
    <?php
    include("AttendanceConn.php");
      if(isset($_POST['submit_attend'])){
        // $sitterid=$_POST['babysitter_id'];
        $chid_name=$_POST['chid_name'];
        $chid_roll=$_POST['roll_no'];
        $status=$_POST['status'];
        $date=date("Y-m-d");


        
        $sql="INSERT INTO attendance(Rollno,chid_name,c_status,adddate) VALUES ('$chid_roll',' $chid_name',' $status','$date') ";
        $result=mysqli_query($conn,$sql);
         if($result){
            echo '<script> alert("Attendance Marked Successfully");
                      </script>';
            }
            else{
                echo "Attendance Marked Unsuccessfull";
            }
        
    }

    ?>  
    <button class="back-to-main" onclick="window.location.href = 'index.php';">Back</button>
</body>
</html>



