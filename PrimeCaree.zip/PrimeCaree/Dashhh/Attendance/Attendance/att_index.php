<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chidrens Attendance</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    /* Basic styling for the cards */
    .card {
      width:100%;
      height: auto;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 20px;
      margin: 20px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      background-color: #fff;
    }

    /* Styling for the container holding the cards */
    .card-container {
      display: flex; /* This will make the cards display side by side */
      justify-content: bottom;
      margin top: 20px; /* Centers the cards horizontally */
    }
    
    .back{
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 150px;
            margin-left:1150px;
            cursor: pointer;
            border-radius: 8px;
        }
  </style>
</head>
<body style="background-image:url(atten.jpg);background-size: cover;">
<div class="card-container">
   <div class="card" style="width: 18rem;">
    <img src="https://i.pinimg.com/originals/53/4e/88/534e88b78d870ae28cb8c2a380f5f41f.png" class="card-img-top" alt="logo">
      <div class="card-body">
       <h5 class="card-title">Mark Attendance</h5>
       <a href="ChildAttendance.php" class="btn btn-primary">Click Here</a>
      </div>
   </div>

   <div class="card" style="width: 18rem;">
     <img src="https://global-uploads.webflow.com/624fdc5e82dc83514cd9d166/630327e837665d3e7d968e54_aaaaa.png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Attendance Record</h5>
        <a href="checkattendance.php" class="btn btn-primary">Click Here</a>
      </div>
    </div>
 </div>

<button class="back" onclick="window.location.href = 'PrimeCaree\index.php';">Back</button>
</body>
</html>
