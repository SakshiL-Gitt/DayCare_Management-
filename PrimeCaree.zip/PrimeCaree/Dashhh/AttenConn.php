<?php
$server="localhost";
$user="root";
$pp="";
$db="sejal";
  $conn=new mysqli($server,$user,$pp,$db);
  if($conn->connect_error){
    die("connection failed".$conn->connect_error);
  }
  
  ?>
