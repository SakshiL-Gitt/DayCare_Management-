<!DOCTYPE html>
<html>
<head>
    <title>Service Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<?php
require_once('config.php');
?>

<?php
if (isset($_POST["submit"])) {
    $sname = isset($_POST["sname"]) ? $_POST["sname"] : "";
    $description = isset($_POST["description"]) ? $_POST["description"] : "";
    $date_created = date("Y-m-d H:i:s");
    $date_updated = $date_created; // Initially, date_updated is same as date_created

    // SQL query to insert data into the database
    $sql = "INSERT INTO services (sname, description, date_created, date_updated)
    VALUES ('$sname', '$description', '$date_created', '$date_updated')";

    if ($con->query($sql) == TRUE) {
        echo '<script>
         alert("Service added successfully..");
         </script>';
    } else {
        echo '<script>
         alert("Error");
         </script>' . $sql . "<br>" . $con->error;
    }
}
?>

<body>

<div class="container">
    <h2>Add Service </h2>
    <form method="post" action=" addservice.php">
        <label for="sname">Service Name:</label>
        <input type="text" name="sname" id="sname">

        <label for="description">Description:</label>
        <textarea name="description" id="description"></textarea>

        <input type="submit" name="submit" value="Submit">
    </form>
</div>
<button class="back-to-main" onclick="window.location.href = 'services.php';" style="
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 65px;
            margin-left:1125px;
            cursor: pointer;
">Back</button>

</body>
</html>
