<!-- for babysitter  -->
<?php

require_once('config.php');

$id = $_GET['id'];

// Prepare the delete query
$sql = "DELETE FROM services WHERE id = :id";
$stmt = $con->prepare($sql);

// Bind the parameter
$stmt->bindParam(':id', $id, PDO::PARAM_INT);

// Execute the query
$result = $stmt->execute();

if ($result) {
    header("Location: services.php?msg=Record Deleted Successfully");
    echo '<script>
         alert("Record Deleted Successfully");
         </script>';
} else {
    echo "Error deleting record: " . $stmt->errorInfo()[2];
}
?>
