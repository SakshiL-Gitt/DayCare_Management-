<!-- for babysitter  -->
<?php

require_once('config.php');

$id = $_GET['id'];

// Prepare the delete query
$sql = "DELETE FROM babysitter_details WHERE id = :id";
$stmt = $con->prepare($sql);

// Bind the parameter
$stmt->bindParam(':id', $id, PDO::PARAM_INT);

// Execute the query
$result = $stmt->execute();

if ($result) {
    header("Location: babysitter.php?msg=Record Deleted Successfully");
} else {
    echo "Error deleting record: " . $stmt->errorInfo()[2];
}
?>
