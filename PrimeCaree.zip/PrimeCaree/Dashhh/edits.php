<!DOCTYPE html>
<html>
<head>
    <title>Edit Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<?php
require_once('config.php');

// Check if ID is provided in the URL
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Fetch data for the provided ID
    $stmt = $con->prepare("SELECT * FROM services WHERE id = :id LIMIT 1");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    // If ID is not provided, initialize an empty row
    $row = array('sname' => '', 'description' => '');
}

// Check if form is submitted
if(isset($_POST['submit'])) {
    $sname = $_POST['sname'];
    $des = $_POST['description'];
    $id = $_POST['id'];

    // Update the data in the database
    $query = "UPDATE services SET sname=?, description=? WHERE id=?";
    $stmt = $con->prepare($query);
    $result = $stmt->execute([$sname, $des, $id]);
   
    if($result) {
        echo '<script>
        alert("Service updated successfully..");
        </script>';
    } else {
        echo "Update failed";
    }
}
?> 

<div class="container">
    <h2>Edit Service</h2>
    <div class="content py-3">
        <form method="post" action="edits.php">
            <!-- Hidden field to store the ID -->
            <input type="hidden" name="id" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
            <label for="sname">Service Name:</label>
            <input type="text" name="sname" id="sname" value="<?= $row['sname'] ?>">

            <label for="description">Description:</label>
            <textarea name="description" id="description"><?= $row['description'] ?></textarea>

            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
</div>
<button class="back-to-main" onclick="window.location.href = 'services.php';" style="
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 65px;
            margin-left:1125px;
            cursor: pointer;
">Back</button>

</body>
</html>
