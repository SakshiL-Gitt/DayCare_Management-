<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
  </head>
  <body>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
  </body>
</html>

<?php
require_once('config.php');
?>

<style>
    #cimg{
        object-fit:scale-down;
        object-position:center center;
        height:200px;
        width:200px;
    }

    
</style>

<?php 

if(isset($_POST['save']))
{
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
   // $skill = $_POST['skills'];
    $yoe = $_POST['years_experience'];
  //  $achievement = $_POST['achievement'];
    $skill = $_POST['other'];
     $image = $_POST['image'];

    $query = "insert into babysitter_details(firstname,middlename,lastname,gender,email,contact,address,yearofexper,skills,profile) 
    values(?,?,?,?,?,?,?,?,?,?)";                        
    $stmp = $con->prepare($query );
    $result = $stmp->execute([$firstname , $middlename , $lastname, $gender,$email,$contact,$address,$yoe,$skill,$image]);
   
    if($result)
    {
        header("Location: babysitter.php?msg=Record Added Successfully");
    }
    else{
        echo "not saved";
    }

}

?>  
<div class="content py-3">
    <form action="addbabysitter.php" method="post">
    <div class="container-fluid">
        <div class="card card-outline card-info shadow rounded-0">
            <div class="card-header">
                <h4 class="card-title"><?= isset($id) ? "Add New Baby Sitter" : "Manage Baby Sitter" ; ?></h4>
            </div>
            <div class="card-body">
                <div class="container-fluid">
                    <form action="" id="babysitter-form">
                        <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">
                        <fieldset>
                            <legend class="text-navy">Personal Information</legend>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="firstname" class="control-label text-primary">First Name</label>
                                    <input type="text" autofocus class="form-control form-control-border" name="firstname" id="firstname" required value="<?= isset($firstname) ? $firstname : "" ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="middlename" class="control-label text-primary">Middle Name</label>
                                    <input type="text" class="form-control form-control-border" name="middlename" id="middlename" placeholder="(Optional)..." value="<?= isset($middlename) ? $middlename : "" ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="lastname" class="control-label text-primary">Last Name</label>
                                    <input type="text" class="form-control form-control-border" name="lastname" id="lastname" required value="<?= isset($lastname) ? $lastname : "" ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="" class="control-label text-primary">Gender</label>
                                </div>
                                <div class="form-group col-auto">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="genderMale" name="gender" value="Male" required <?= isset($gender) && $gender == "Male" ? "checked" : "" ?>>
                                        <label for="genderMale" class="custom-control-label">Male</label>
                                    </div>
                                </div>
                                <div class="form-group col-auto">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="genderFemale" name="gender" value="Female" <?= isset($gender) && $gender == "Female" ? "checked" : "" ?>>
                                        <label for="genderFemale" class="custom-control-label">Female</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="email" class="control-label text-primary">Email</label>
                                    <input type="email" class="form-control form-control-border" name="email" id="email" required  value="<?= isset($email) ? $email : "" ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="contact" class="control-label text-primary">Contact #</label>
                                    <input type="text" class="form-control form-control-border" name="contact" id="contact" required value="<?= isset($contact) ? $contact : "" ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="address" class="control-label text-primary">Address</label>
                                    <textarea name="address" id="address" class="form-control form-control-border" rows="2" required><?= isset($address) ? $address : "" ?></textarea>
                                </div>
                            </div>
                            <!-- <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="skills" class="control-label text-primary">Skills</label>
                                    <textarea name="skills" id="skills" class="form-control form-control-border" rows="2" required><?= isset($skills) ? $skills : "" ?></textarea>
                                </div>
                            </div> -->
                        </fieldset>
                        <fieldset>
                            <legend class="text-navy">Professional Information</legend>
                            <div class="form-group col-md-4">
                                <label for="years_experience" class="control-label text-primary">Years of Experience</label>
                                <input type="number" class="form-control form-control-border text-right" name="years_experience" id="years_experience" required value="<?= isset($years_experience) ? $years_experience : "" ?>">
                            </div>
                            <!-- <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="achievement" class="control-label text-primary">Achievements</label>
                                    <textarea name="achievement" id="achievement" class="form-control form-control-border" rows="2" placeholder="Write Achievements here (If Any)"><?= isset($achievement) ? $achievement : "" ?></textarea>
                                </div>
                            </div> -->
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="other" class="control-label text-primary">Other Information</label>
                                    <textarea name="other" id="other" class="form-control form-control-border" rows="2" placeholder="Write here"><?= isset($other) ? $other : "" ?></textarea>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend class="text-navy">Image</legend>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="img" class="control-label text-muted">Choose Image</label>
                                    <input type="file" id="img" name="image" class="form-control form-control-border" accept="image/png,image/jpeg" onchange="displayImg(this,$(this))">
                                    
                                </div>
                            </div>
                            
                            <br>
                        </fieldset>
                        <div>
                                <input type="submit" name="save" value="Save">
                            </div>
                        
                       
                    </form>
                </div>
            </div>
            
        </div>
    </div>
    </form>
</div>
