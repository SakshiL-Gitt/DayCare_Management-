<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
  </head>
  <body>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
  </body>
</html>

<?php
require_once('config.php');
?>

<style>
    #cimg{
        object-fit:scale-down;
        object-position:center center;
        height:200px;
        width:200px;
    }
</style>
<?php
if (isset($_POST["submit"])) {
    $sname = isset($_POST["sname"]) ? $_POST["sname"] : "";
    $description = isset($_POST["description"]) ? $_POST["description"] : "";
    $date_created = date("Y-m-d H:i:s");
    $date_updated = $date_created; // Initially, date_updated is same as date_created

    // SQL query to insert data into the database
    $sql = "INSERT INTO services (sname, description, date_created, date_updated)
    VALUES ('$sname', '$description', '$date_created', '$date_updated')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<div class="content py-3">
    <form action="addservices.php" method="POST">
    <div class="container-fluid">
        <div class="card card-outline card-info shadow rounded-0">
            <div class="card-header">
                <h4 class="card-title"><?= isset($id) ? "Add New Service" : "Manage Services" ; ?></h4>
            </div>
            <div class="card-body">
                <div class="container-fluid">
                        <fieldset>
                            <legend class="text-navy">Add Service</legend><br><br>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="firstname" class="control-label text-primary">Service Name</label><br><br>
                                    <input type="text" autofocus class="form-control form-control-border" name="sname" id="sname" required value="<?= isset($sname) ? $sname : "" ?>"><br><br>
                                </div>
                            </div>
                        </fieldset>
                            <div class="row">
                                <div class="form-group col-md-5">
                                    <label for="address" class="control-label text-primary">Service Description</label><br><br>
                                    <textarea name="address" id="address" class="form-control form-control-border" rows="4" required><?= isset($desc) ? $desc : "" ?></textarea><br>
                                </div>
                            </div>
                            <div>
                                <input type="submit" name="save" value="Save">
                            </div>
                        </div>
                    </div>
                    </form>