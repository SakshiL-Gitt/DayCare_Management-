<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Attendance</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />



  <style>
    form{
      padding: 20px;
    }

    </style>

</head>
<body>
  <form method="GET">
    <br>
    <br>
  <input type="date" value="<?= isset($_GET['date'])==true ? $_GET['date']:'' ?>" id="date" padding="20px" name="date"><br>
  <br>
   <button type="submit" class="btn btn-primary"  name="c_submit" > Filter </button><br>

    <table class="table table-hover text-center">
        <thead class="table-dark">
          <tr>
          <th scope="col">BabySitter_ID</th>
            <th scope="col">Name</th>
            <th scope="col">Status</th>
            <th scope="col">Date</th>
          </tr>
        </thead>
         <tbody>
            <?php
                
                include('AttenConn.php');
                if(isset($_GET['date']) && $_GET['date'] !=''){
                $select_date=$_GET['date'];
                $sql = "SELECT * from  bsattendance where adddate='$select_date'";
                $result = $conn->query($sql);
              while ($row = $result->FETCH_ASSOC())
              {
                ?>
                    <tr>
                     <th><?php echo $row['id']?></th><br>
                      <th><?php echo $row['bsname']?></th><br>
                      <th><?php echo $row['bsstatus']?></th>
                      <th><?php echo $row['adddate']?></th>
                    </tr>


                    <?php

              }

                  
              }
              
                
              
                

              ?> 
            
          
       </tbody> 
      </table>

  </div>
  <button class="back-to-main" onclick="window.location.href = 'localhost/PrimeCaree/Dashhh/bsattenindex.php';" style="
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 250px;
            margin-left:1120px;
            cursor: pointer;
">Back</button>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
            </form>
</body>

</html>