<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BabySitter Attendance</title>
    <style>

       body{
        font-family:Arial,sans-serif;
        margin:0;
        padding :0;
        background-image:url('https://i.pinimg.com/originals/6d/60/f8/6d60f8c86bb29ae65c26370be7429f0d.jpg');
       }

       .container{
        max-width:800px;
        margin: 20px auto;
        padding:20px;
        background-color:#fff;
        border-radius:8px;
        box-shadow:0 0 10px rgba(0,0,0,0.1);
       }
       h1{
        text-align:center;
       }
       form{
        margin-top:50px;
       }
       label{
        display:block;
        margin-bottom:8px;
       }
       input[type="submit"]{
        background-color:#0096FF;
        color:white;
        padding:5px 20px;
        border:none;
        border-radius:4px;
        cursor:pointer;
       font-size: 16px;
       }
       input[type="submit"]:hover{
        background-color: #0096FF;
       }
       

        </style>
</head>
<body>
    <div class="container">
        <h1>BabySitter Attendance</h1>
        <form method="post">
            BabySitter Name  :   <input type="text" id="bsname" name="bsname" required><br><br>
            BabySitter ID    :   <input type="text" id="bsid" name ="bsid" required><br><br>
            <label for="chid_attend" >BabySitter Attendance:</label>
            <input type="checkbox" name="status" value="present">Present<br>
            <input type="checkbox" style= "color:#990FF" name="status" value="absent" >Absent<br><br>
            <input type="submit" value="submit_attendance" name="submit_attend">
    </form>
    </div>

 <div>
    <?php
    include("AttenConn.php");
      if(isset($_POST['submit_attend'])){
        // $sitterid=$_POST['babysitter_id'];
        $bsname=$_POST['bsname'];
        $bsid=$_POST['bsid'];
        $status=$_POST['status'];
        $date=date("Y-m-d");


        
        $sql="INSERT INTO bsattendance(id,bsname,bsstatus,adddate) VALUES ('$bsid',' $bsname',' $status','$date') ";
        $result=mysqli_query($conn,$sql);
         if($result){
            echo '<script> alert("Attendance Marked Successfully");
                      </script>';
            }
            else{
                echo "Attendance Marked Unsuccessfull";
            }
        
    }

    ?>  
     <button class="back-to-main" onclick="window.location.href = 'bsattenindex.php';" style="
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 150px;
            margin-left:1130px;
            cursor: pointer;
">Back</button>
</body>
</html>



