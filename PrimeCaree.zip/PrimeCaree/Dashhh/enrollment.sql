-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2024 at 05:06 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cdc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `id` int(11) NOT NULL,
  `child_fname` varchar(255) DEFAULT NULL,
  `child_mname` varchar(255) DEFAULT NULL,
  `child_lname` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `allergy` varchar(255) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `parent_fname` varchar(255) DEFAULT NULL,
  `parent_mname` varchar(255) DEFAULT NULL,
  `parent_lname` varchar(255) DEFAULT NULL,
  `contact` bigint(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`id`, `child_fname`, `child_mname`, `child_lname`, `dob`, `allergy`, `gender`, `parent_fname`, `parent_mname`, `parent_lname`, `contact`, `email`, `address`) VALUES
(1, 'csns,mnc', 'sbcm', 'sncbm', '2024-03-03', 'scv', 'Female', 'vewvev', 'vdv', 'scdsv', 9579147633, 'dsai5655@gmail.com', 'At post saur'),
(2, 'Purva', 'Mangesh', 'Deshmukh', '2024-02-25', 'hytil;kdwn', 'female', 'Mangesh', 'Sahebrao', 'Deshmukh', 9579147633, 'dsai5655@gmail.com', 'at . Post saur'),
(3, 'Purva', 'Mangesh', 'Deshmukh', '2024-02-25', 'hytil;kdwn', 'female', 'Mangesh', 'Sahebrao', 'Deshmukh', 9579147633, 'dsai5655@gmail.com', 'at . Post saur'),
(4, 'Purva', 'Mangesh', 'Deshmukh', '2024-02-25', 'hytil;kdwn', 'female', 'Mangesh', 'Sahebrao', 'Deshmukh', 9579147633, 'dsai5655@gmail.com', 'at . Post saur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enrollment`
--
ALTER TABLE `enrollment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
