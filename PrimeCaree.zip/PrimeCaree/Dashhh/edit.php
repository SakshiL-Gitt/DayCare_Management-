<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
  </head>
  <body>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
  </body>
</html>

<?php
require_once('config.php');
?>

<style>
    #cimg{
        object-fit:scale-down;
        object-position:center center;
        height:200px;
        width:200px;
    }

    
</style>

<?php 

if(isset($_POST['update']))
{
    
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $skill = $_POST['skills'];
    $yoe = $_POST['years_experience'];
    $achievement = $_POST['achievement'];
    $otherinfo = $_POST['other'];
    $image = $_POST['img'];
   
    $id = $_POST['id'];

    $query = "UPDATE babysitter_details SET firstname=?, middlename=?, lastname=?, gender=?, email=?, contact=?,address=?,  yearofexper=?,skills=?, profile=? WHERE id=?";
    $stmt = $con->prepare($query);
    $result = $stmt->execute([$firstname, $middlename, $lastname, $gender, $email, $contact, $address, $yoe, $skill,  $image, $id]);
   
    if($result) {
        header("Location: babysitter.php?msg=Record Updated successfully");
    } else {
        echo "Update failed";
    }

}

?>  
<div class="content py-3">
    <form action="edit.php" method="post">
    <form action="addbabysitter.php" method="post">
    <div class="container-fluid">
        <div class="card card-outline card-info shadow rounded-0">
            <div class="card-header">
                <h4 class="card-title"><?= isset($id) ? "Add New Baby Sitter" : "Edit Employee Information" ; ?></h4>
            </div>
            
            <?php
            // $id = $_GET['id'];
            // $sql = "select * from 'babysitter_details' where id = $id LIMIT 1";
            // $result = $con->query($sql);
            // $row = $result->fetch(PDO::FETCH_ASSOC)
           
        
            $id = $_GET['id']; // Assuming you're passing the ID through GET method
            $stmt = $con->prepare("SELECT * FROM babysitter_details WHERE id = :id LIMIT 1");
            $stmt->bindParam(':id', $id);
            $stmt->execute();

            // Fetch data as an associative array
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            ?>
            <div class="card-body">
                <div class="container-fluid">
                    <form action="" id="babysitter-form">
                        <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">
                        <fieldset>
                            <legend class="text-navy">Personal Information</legend>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="firstname" class="control-label text-primary">First Name</label>
                                    <input type="text" autofocus class="form-control form-control-border" name="firstname" id="firstname"  value="<?php echo $row['firstname'] ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="middlename" class="control-label text-primary">Middle Name</label>
                                    <input type="text" class="form-control form-control-border" name="middlename" id="middlename" value="<?php echo $row['middlename'] ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="lastname" class="control-label text-primary">Last Name</label>
                                    <input type="text" class="form-control form-control-border" name="lastname" id="lastname" value="<?php echo $row['lastname'] ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="" class="control-label text-primary">Gender</label>
                                </div>
                                <div class="form-group col-auto">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="genderMale" name="gender" value="Male" value="Male"<?php echo ($row['gender']=='Male')? "checked":""; ?>>
                                        <label for="genderMale" class="custom-control-label">Male</label>
                                    </div>
                                </div>
                                <div class="form-group col-auto">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="genderFemale" name="gender" value="Female" value="Female"<?php echo ($row['gender']=='Female')? "checked":""; ?>>
                                        <label for="genderFemale" class="custom-control-label">Female</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="email" class="control-label text-primary">Email</label>
                                    <input type="email" class="form-control form-control-border" name="email" id="email" value="<?php echo $row['email'] ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="contact" class="control-label text-primary">Contact #</label>
                                    <input type="text" class="form-control form-control-border" name="contact" id="contact" required value="<?php echo $row['contact'] ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="address" class="control-label text-primary">Address</label>
                                    <textarea name="address" id="address" class="form-control form-control-border" rows="2" ><?php echo $row['address']; ?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="skills" class="control-label text-primary">Skills</label>
                                    <textarea name="skills" id="skills" class="form-control form-control-border" rows="2"><?php echo $row['skill'] ?></textarea>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend class="text-navy">Professional Information</legend>
                            <div class="form-group col-md-4">
                                <label for="years_experience" class="control-label text-primary">Years of Experience</label>
                                <input type="number" class="form-control form-control-border text-right" name="years_experience" id="years_experience" value="<?php echo $row['yearofexper'] ?>">
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="achievement" class="control-label text-primary">Achievements</label>
                                    <textarea name="achievement" id="achievement" class="form-control form-control-border" rows="2"> <?php echo $row['achievement'] ?></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="other" class="control-label text-primary">Other Information</label>
                                    <textarea name="other" id="other" class="form-control form-control-border" rows="2" ><?php echo $row['otherinfo'] ?></textarea>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend class="text-navy">Image</legend>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="img" class="control-label text-muted">Choose Image</label>
                                    <input type="file" id="img" name="img" class="form-control form-control-border" accept="image/png,image/jpeg" onchange="displayImg(this,$(this))" >
                                    <?php if(isset($row['img']) && !empty($row['img'])): ?>
                                    <img src="<?php echo $row['img']; ?>" alt="Selected Image" id="selected-image" style="max-width: 100%; height: auto; margin-top: 10px;">
                                     <?php endif; ?>
                                    
                                </div>
                            </div>
                            
                            
                        </fieldset>
                        <fieldset>

                             <div style="margin-top: 40px;">
                                <input type="submit" name="update" value="Update" class="btn btn-primary mr-2" class="btn btn-secondary"> 

                                <input type="submit" name="cancle" value="Cancle" class="btn btn-danger mr-2" class="btn btn-secondary">
                            </div>
                        </fieldset>
                       
                    </form>
                </div>
            </div>
            
        </div>
    </div>
    </form>
</div>
