<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
  </head>
  <body>
  


  <nav class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color:#00ff5573;">
		List of Employee
  </nav>

	<div class="container">

      <?php

        if(isset($_GET['msg']))
        {
          $msg = $_GET['msg'];
          echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
          '.$msg.'
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }
       ?>
		<a href="addbabysitter.php" class="btn btn-dark mb-3">Add New </a>

        <table class="table table-hover text-center">
          <thead class="table-dark">
            <tr>
              <th scope="col">ID</th>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Email</th>
              <th scope="col">Year of Experience</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  
                  require_once('config.php');
                  

                $sql = "select id,firstname,lastname,email,yearofexper from babysitter_details ";
                $result = $con->query($sql);
                while ($row = $result->fetch(PDO::FETCH_ASSOC))
                {
                  ?>
                      <tr>
                        <th><?php echo $row['id']?></th>
                        <th><?php echo $row['firstname']?></th>
                        <th><?php echo $row['lastname']?></th>
                        <th><?php echo $row['email']?></th>
                        <th><?php echo $row['yearofexper']?></th>
                        <td>
                              <a href="edit.php?id=<?php echo $row['id'];?>" class="link-dark"><i class="fa-solid fa-pen-to-square fs-6 me-2"></i></a>
                              <a href="delete.php?id=<?php echo $row['id'];?>" class="link-dark"><i class="fa-solid fa-trash fs-6 me-2"></i></a>
                        </td>
                      </tr>


                      <?php



                    
                } 
                $conn = null;

                ?>
              
            
          </tbody>
        </table>
        <button class="back-to-main" onclick="window.location.href = 'index.php';" style="
            background-color: #2691d9;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 180px;
            margin-left:1100px;
            cursor: pointer;
">Back</button>

	</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
  </body>
</html>