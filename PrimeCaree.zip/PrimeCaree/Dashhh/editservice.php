<!DOCTYPE html>
<html>
<head>
    <title>Service Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<?php
require_once('config.php');
?>
<?php 

if(isset($_POST['update']))
{
    
    $sname = $_POST['sname'];
    $des = $_POST['description'];
   
    $id = $_POST['id'];

    $query = "UPDATE services SET sname=?, des=? WHERE id=?";
    $stmt = $con->prepare($query);
    $result = $stmt->execute([$sname, $des, $id]);
   
    if($result) {
        echo "updated";
        //header("Location: babysitter.php?msg=Record Updated successfully");
    } else {
        echo "Update failed";
    }

}

?> 

<div class="content py-3">
    <form action="editservice.php" method="post">
    
    <div class="container-fluid">
        <div class="card card-outline card-info shadow rounded-0">
            <div class="card-header">
                <h4 class="card-title"><?= isset($id) ? "Add New Baby Sitter" : "Edit Services Information" ; ?></h4>
            </div>
            
            <?php
            // $id = $_GET['id'];
            // $sql = "select * from 'babysitter_details' where id = $id LIMIT 1";
            // $result = $con->query($sql);
            // $row = $result->fetch(PDO::FETCH_ASSOC)
           
        
            $id = $_GET['id']; // Assuming you're passing the ID through GET method
            $stmt = $con->prepare("SELECT * FROM services WHERE id = :id LIMIT 1");
            $stmt->bindParam(':id', $id);
            $stmt->execute();

            // Fetch data as an associative array
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            ?>
    <h2>Updates Service </h2>

    <form method="post" action=" editservice.php">
    <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">
        <label for="sname">Service Name:</label>
        <input type="text" name="sname" id="sname"  value="<?php echo $row['sname'] ?>">

        <label for="description">Description:</label>
        <textarea name="description" id="description"  ><?php echo $row['description']; ?></textarea>

        <input type="submit" name="submit" value="Submit">
    </form>
</div>

</body>
</html>
