<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
  </head>
  <body>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
  </body>
</html>

<?php
require_once('config.php');
?>

<style>
    #cimg{
        object-fit:scale-down;
        object-position:center center;
        height:200px;
        width:200px;
    }

    
</style>

<!--  -->
<div class="content py-3">
    <form action="view.php" method="post">
    
    <div class="container-fluid">
        <div class="card card-outline card-info shadow rounded-0">
            <div class="card-header">
                <h4 class="card-title"><?= isset($id) ? "" : "User Details" ; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="users.php" class="btn btn-success mr-2" style="height: 30px; line-height: 18px; background-color: grey; border-color: grey; color: white;">Close Window</a>
               
            </div>
            
            <?php
            // $id = $_GET['id'];
            // $sql = "select * from 'babysitter_details' where id = $id LIMIT 1";
            // $result = $con->query($sql);
            // $row = $result->fetch(PDO::FETCH_ASSOC)
           
        
            $id = $_GET['id']; // Assuming you're passing the ID through GET method
            $stmt = $con->prepare("SELECT * FROM enrollment WHERE id = :id LIMIT 1");
            $stmt->bindParam(':id', $id);
            $stmt->execute();

            // Fetch data as an associative array
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            ?>
            <style>
    .card-body {
        padding: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .control-label {
        font-weight: bold;
    }

    /* Optional: Add more styling as needed */
</style>

<div class="card-body">
    <div class="container-fluid">
        <form action="" id="">
            <input type="hidden" name="id" value="<?= isset($id) ? $id : '' ?>">

            <legend class="text-navy">Information</legend>
            <div class="row">
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Child First Name:</label>
                    <?php echo $row['child_fname'] ?>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Child Surname:</label>
                    <?php echo $row['child_lname'] ?>
                </div>

                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Date of Birth:</label>
                    <?php echo $row['dob'] ?>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Allergy:</label>
                    <?php echo $row['allergy'] ?>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Parent Name:</label>
                    <?php echo $row['parent_fname'] ?>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Parent Surname:</label>
                    <?php echo $row['parent_lname'] ?>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Email:</label>
                    <?php echo $row['email'] ?>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Contact:</label>
                    <?php echo $row['contact'] ?>
                </div>

                <div class="form-group col-md-4">
                    <label class="control-label text-primary">Address:</label>
                    <?php echo $row['address'] ?>
                </div>
            </div>
        </form>
    </div>
</div>

    </div>
    </form>
</div>
