<?php
require_once('Registerconfig.php');
?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<div>
               <?php 

                    if(isset($_POST['submit']))
                    {
                        $child_fname = $_POST['child_fname'];
                        $child_mname = $_POST['child_mname'];
                        $child_lname = $_POST['child_lname'];
                        $dob = $_POST['dob'];
                        $allergy = $_POST['allergy'];
                        $gender = $_POST['gender'];
                   
                        $parent_fname = $_POST['parent_fname'];
                        $parent_mname = $_POST['parent_mname'];
                        $parent_lname = $_POST['parent_lname'];
                        $contact = $_POST['contact'];
                        $email = $_POST['email'];
                        $address = $_POST['address'];
                        // $image = $_POST['image'];

                        $query = "insert into enrollment (child_fname,child_mname,child_lname,dob,allergy,gender,parent_fname,parent_mname,parent_lname,contact,email,address) 
                        values(?,?,?,?,?,?,?,?,?,?,?,?)";                        
                        $stmp = $con->prepare($query );
                        $result = $stmp->execute([$child_fname , $child_mname , $child_lname, $dob,$allergy,$gender,$parent_fname,$parent_mname,$parent_lname,$contact,$email,$address]);
                       
                        if($result)
                        {
                            echo '<script> alert("Register Successfully");
                                  </script>';
                        }
                        else{
                            echo "Register Unsuccessfull";
                        }

                    }

                ?>  
    
    </div>










    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>


<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
  Proceed For Payment
</button>

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle">
  <div class="modal-dialog modal-dialog-centered" >
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Payment Form </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         </button>
      </div>
      <div class="modal-body">
      <form style="padding:25px;" method="post" action="">
            <div text-align: center;>



            <div class="col-5">
            <?php
            if(isset($_GET['id'])) {
          
            $id = $_GET['id']; // Assuming you're passing the ID through GET method
            $stmt = $con->prepare("SELECT * FROM enrollment WHERE id = :id LIMIT 1");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            else{
              $row = array('parent_fname' => '', 'email' => '','contact' => '');
            }
            ?>

                <label for="fname"><i class="fa fa-user"></i>Full name</label><br>
                <input type="text" id="name" name="name" value="<?php echo $row['parent_fname'] ?>"/><br>

                <label for="email"><i class="fa fa-envelop"></i>Email</label><br>
                <input type="email" id="email" name="email" value="<?php echo $row['email'] ?>">

                <input type="hidden" value="<?php echo'OID'.rand(100,1000);?>"name="enrollid">
                <label for="email"><i class="fa fa-envelop"></i>Duration(In weeks)</label><br>
                <input type="text" id="dur" name="dur" placeholder="Enter no. of weeks"><br>
                <input type="hidden" value="<?php echo 100;?>"name="amt" id="amt"> 

                <label for="mobile"><i class="fa fa-mobile"></i>Mobile</label><br>
                <input type="text" id="mobile" name="mobile" value="<?php echo $row['contact'] ?>"><br><br>
                <input type="button" name="pay" value="Pay now" id="submit" onclick="pay_now()">
  
             </div>
            </div>
       </form>

<script>
    function pay_now(){
      var name=jQuery('#name').val();
      var amt=jQuery('#amt').val();
      var dur=jQuery('#dur').val();
      var email=jQuery('#email').val();
      var mobile=jQuery('#mobile').val();


    jQuery.ajax({ 
               type:'post',
               url:'payment_process.php',
               data:"name="+name+"&dur"+dur+"&email"+email+"&mobile"+mobile,
               success:function(result){
                 var options = {
                  "key": "rzp_test_WTYBWMgBUTcYie", // Enter the Key ID generated from the Dashboard
                  "amount":amt*100*dur, 
                 "currency": "INR",
                 "name": "Prime Care",
                 "description": "Test Transaction",
                  "image": "https://example.com/your_logo",
                 "handler": function (response){
        
                     jQuery.ajax({ 
                      type:'post',
                      url:'payment_process.php',
                      
                      data:"payment_id="+response.razorpay_payment_id,
                      success:function(result){
                     window.location.href="thank_you.php";
                     
           }
          });


        }
     };

     var rzp1 = new Razorpay(options);
             rzp1.open();


   }
});
}
</script>



      </div>   
    </div>
  </div>
</div>

</body>
</html>





